package actividadHibernate
import jakarta.persistence.*


@Entity
@Table(name ="pedidos")
class Pedido(

    @ManyToOne
    @JoinColumn(name = "cif_taller")
    var taller:Taller?=null,

    @ManyToOne(cascade = [CascadeType.ALL], fetch = FetchType.LAZY)
    @JoinColumn(name = "dni_cliente")
    var cliente: Cliente,

    @Column(name="descripcion")
    var descripcion:String,

    @Id
    @Column(name="id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    var id: Int?=null
) {
}