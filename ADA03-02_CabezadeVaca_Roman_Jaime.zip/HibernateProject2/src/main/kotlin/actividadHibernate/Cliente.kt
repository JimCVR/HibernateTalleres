package actividadHibernate
import jakarta.persistence.*

@Entity
@Table(name = "clientes")
class Cliente (

    @Column(name = "nombre")
    var nombre: String,
    @Column(name = "email")
    var email: String,

    @OneToOne(cascade = [CascadeType.ALL])
    @JoinColumn(name = "id_direccion")
    var direccion: Direccion,

    @OneToMany(mappedBy = "cliente", cascade = [CascadeType.ALL], fetch = FetchType.LAZY)
    var pedidos:MutableSet<Pedido>?=null,


    @ManyToMany(cascade = [CascadeType.ALL], fetch = FetchType.LAZY)
    @JoinTable(
        name = "cliente_taller",
        joinColumns = [JoinColumn (name = "id_cliente")],
        inverseJoinColumns = [JoinColumn (name = "id_taller")]
    )
    var talleres: MutableSet<Taller>?=null,

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    var id: Long? = null

){
}

/*
* Realiza la implementación del siguiente supuesto.
Según la lógica de negocio que se ha pensado, en nuestra aplicación se establece que:
1º GESTION DE DIRECCIONES

  **  1 cliente únicamente puede tener 1 dirección
   ** 1 taller únicamente puede tener 1 dirección
   ** La dirección debe estar en una tabla independiente, con una clave primaria autogenerada
  **  La clave de dirección debe viajar a las tablas de cliente y de taller
  ***  Las relaciones deben ser bidireccionales, es decir, si obtengo una dirección, debo poder acceder
  ***
  *
  *   al cliente o taller a quien pertenece dicha dirección.

* ****xx*****
* 2º GESTIÓN DE PEDIDOS
    1 cliente puede tener múltiples pedidos
    1 taller puede tener múltiples pedidos
    Pero varios pedidos sólo pueden ser de 1 cliente y,
    varios pedidos sólo pueden ser de 1 taller.
    La tabla pedidos tiene un id autogenerado
    La tabla pedidos tiene un campo "descripcion" de tipo VARCHAR(255)
3º GESTION DE CLIENTES con TALLERES
    Se establece que muchos clientes pueden tener muchos talleres.
    Definir una relación bidireccional de muchos a muchos entre clientes y talleres
*
*
* */