
rootProject.name = "HibernateProject2"

